/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.personas;

import modelo.abstractas.Empleado;
import modelo.enums.Turno;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Medico extends Empleado {
    private String numeroLicencia;
    private String especialidad;
    private Turno turno;
    private List<String> pacientesAsignados;

    public Medico(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                  String email, String legajo, LocalDate fechaContratacion, 
                  double salarioBase, String numeroLicencia, String especialidad, Turno turno) {
        
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        
        this.numeroLicencia = numeroLicencia;
        this.especialidad = especialidad;
        this.turno = turno;
        this.pacientesAsignados = new ArrayList<>();
    }
    
    @Override
    public double calcularSalario() {
        double bonoAntiguedad = antiguedad() * 50000;
        double bonoEspecialidad = 200000;
        return getSalarioBase() + bonoAntiguedad + bonoEspecialidad;
    }

    public void agregarPacienteAsignado(String idPaciente) {
        if (idPaciente != null) {
            pacientesAsignados.add(idPaciente);
        }
    }

    public List<String> getPacientesAsignados() {
        return new ArrayList<>(pacientesAsignados);
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public Turno getTurno() {
        return turno;
    }

    @Override
    public String obtenerTipo() {
        return "Médico";
    }

    @Override
    public String toString() {
        return "Médico: " + super.toString() + " | Especialidad: " + especialidad;
    }
    
}
