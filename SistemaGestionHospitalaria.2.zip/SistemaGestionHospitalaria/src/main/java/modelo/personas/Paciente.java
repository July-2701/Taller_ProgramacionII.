/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.personas;

import modelo.abstractas.Persona;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class Paciente extends Persona {
    private String historiaClinicaId;
    private String grupoSanguineo;
    private List<String> alergias;
    private List<String> contraindicaciones;
    
    public Paciente(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                    String email, String historiaClinicaId, String grupoSanguineo) {
        
        super(id, nombre, apellido, fechaNacimiento, email);
        
        this.historiaClinicaId = historiaClinicaId;
        this.grupoSanguineo = grupoSanguineo;
        this.alergias = new ArrayList<>();
        this.contraindicaciones = new ArrayList<>();
    }
    
    public void agregarAlergia(String alergia) {
        if (alergia != null && !alergia.trim().isEmpty()) {
            this.alergias.add(alergia.trim());
        }
    }
    
    public void agregarContraindicacion(String contraindicacion) {
        if (contraindicacion != null && !contraindicacion.trim().isEmpty()) {
            this.contraindicaciones.add(contraindicacion.trim());
        }
    }
    
    public List<String> getAlergias() {
        return new ArrayList<>(alergias);
    }
    
    public List<String> getContraindicaciones() {
        return new ArrayList<>(contraindicaciones);
    }
    
    public String getHistoriaClinicaId() {
        return historiaClinicaId;
    }
    
    public String getGrupoSanguineo() {
        return grupoSanguineo;
    }
    
    @Override
    public String obtenerTipo() {
        return "Paciente";
    }
    
    @Override
    public String toString() {
        return "Paciente: " + super.toString() + " | Historia Clínica: " + historiaClinicaId;
    }
}
