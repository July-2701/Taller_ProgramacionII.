/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.personas;

import modelo.abstractas.Empleado;
import modelo.enums.Turno;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Enfermero extends Empleado {

    private Turno turno;
    private String areaAsignada;
    private List<String> pacientesACargo;

    public Enfermero(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                     String email, String legajo, LocalDate fechaContratacion, 
                     double salarioBase, Turno turno, String areaAsignada) {
        
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        
        this.turno = turno;
        this.areaAsignada = areaAsignada;
        this.pacientesACargo = new ArrayList<>();
    }

    public void asistirCirugia() {
        System.out.println("Enfermero/a " + getNombre() + " asistiendo en cirugía");
    }

    public void agregarPacienteACargo(String idPaciente) {
        pacientesACargo.add(idPaciente);
    }

    public List<String> getPacientesACargo() {
        return new ArrayList<>(pacientesACargo);
    }

    @Override
    public double calcularSalario() {
        double salario = getSalarioBase();
        if (antiguedad() > 5) {
            salario += 100000;
        }
        return salario;
    }

    @Override
    public String obtenerTipo() {
        return "Enfermero";
    }

    @Override
    public String toString() {
        return "Enfermero: " + super.toString() + " | Área: " + areaAsignada;
    }
}
