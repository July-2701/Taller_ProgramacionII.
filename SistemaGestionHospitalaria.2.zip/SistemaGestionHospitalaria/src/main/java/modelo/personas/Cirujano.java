/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.personas;

import modelo.enums.Turno;
import java.time.LocalDate;

public class Cirujano extends Medico {
    private int cirugiasRealizadas;
    private boolean disponibleEmergencias;
            
    public Cirujano(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                    String email, String legajo, LocalDate fechaContratacion, 
                    double salarioBase, String numeroLicencia, String especialidad, 
                    Turno turno) {
        
        super(id, nombre, apellido, fechaNacimiento, email, legajo, 
              fechaContratacion, salarioBase, numeroLicencia, especialidad, turno);
        
        this.cirugiasRealizadas = 0;
        this.disponibleEmergencias = true;
    }
    
    public void realizarCirugia() {
        cirugiasRealizadas++;
        System.out.println("Cirugía realizada por " + getNombre() + " " + getApellido());
    }

    public int getCirugiasRealizadas() {
        return cirugiasRealizadas;
    }

    public boolean isDisponibleEmergencias() {
        return disponibleEmergencias;
    }

    public void setDisponibleEmergencias(boolean disponibleEmergencias) {
        this.disponibleEmergencias = disponibleEmergencias;
    }
    
    @Override
    public double calcularSalario() {
        double salarioBase = super.calcularSalario();
        double bonoCirujano = 300000;
        double bonoCirugias = cirugiasRealizadas * 50000;
        return salarioBase + bonoCirujano + bonoCirugias;
    }
    
    @Override
    public String obtenerTipo() {
        return "Cirujano";
    }

    @Override
    public String toString() {
        return "Cirujano: " + super.toString() + " | Cirugías realizadas: " + cirugiasRealizadas;
    }
}
