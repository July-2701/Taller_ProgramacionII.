/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.hospital;

import java.time.LocalDate;

public class Diagnostico {

    private String id;
    private String descripcion;
    private String receta;
    private LocalDate fecha;
    private String medicoId;

    public Diagnostico(String id, String descripcion, String receta, LocalDate fecha, String medicoId) {
        this.id = id;
        this.descripcion = descripcion;
        this.receta = receta;
        this.fecha = fecha;
        this.medicoId = medicoId;
    }
  
    public String getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public String getReceta() { return receta; }
    public LocalDate getFecha() { return fecha; }
    public String getMedicoId() { return medicoId; }

    @Override
    public String toString() {
        return "Diagnóstico: " + descripcion + " | Fecha: " + fecha;
    }
}