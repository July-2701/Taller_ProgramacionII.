/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.hospital;

import modelo.enums.EstadoCita;
import modelo.personas.Medico;
import modelo.personas.Paciente;
import java.time.LocalDateTime;

public class CitaMedica {

    private String id;
    private Paciente paciente;
    private Medico medico;
    private LocalDateTime fechaHora;
    private String motivo;
    private EstadoCita estado;
    private double costo;
    private String diagnostico;

    public CitaMedica(String id, Paciente paciente, Medico medico, 
                      LocalDateTime fechaHora, String motivo) {
        
        this.id = id;
        this.paciente = paciente;
        this.medico = medico;
        this.fechaHora = fechaHora;
        this.motivo = motivo;
        this.estado = EstadoCita.PENDIENTE;
        this.costo = 0.0;
        this.diagnostico = "";
    }

    public void calcularCosto() {
        if (medico != null) {
            // Costo base según especialidad (ejemplo)
            this.costo = medico.getEspecialidad().equalsIgnoreCase("Cardiología") ? 250000 : 180000;
        }
    }

    public void completar(String diagnostico) {
        this.diagnostico = diagnostico;
        this.estado = EstadoCita.COMPLETADA;
        System.out.println("Cita " + id + " completada con diagnóstico: " + diagnostico);
    }

    public void cancelar() {
        this.estado = EstadoCita.CANCELADA;
        System.out.println("Cita " + id + " ha sido cancelada.");
    }

    public String getId() { return id; }
    public Paciente getPaciente() { return paciente; }
    public Medico getMedico() { return medico; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public String getMotivo() { return motivo; }
    public EstadoCita getEstado() { return estado; }
    public double getCosto() { return costo; }
    public String getDiagnostico() { return diagnostico; }

    public void setEstado(EstadoCita estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Cita #" + id + " | " + paciente.getNombre() + " " + paciente.getApellido() +
               " con " + medico.getNombre() + " " + medico.getApellido() +
               " | " + fechaHora + " | Estado: " + estado;
    }
}