/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package modelo.hospital;

import modelo.enums.EstadoCita;
import modelo.enums.Turno;
import modelo.personas.Cirujano;
import modelo.abstractas.Empleado;
import modelo.personas.Enfermero;
import modelo.personas.Medico;
import modelo.personas.Paciente;
import modelo.hospital.CitaMedica;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Hospital {

    private String nombre;
    private String direccion;
    private List<Empleado> empleados;
    private List<Paciente> pacientes;
    private List<CitaMedica> citas;

    public Hospital(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.empleados = new ArrayList<>();
        this.pacientes = new ArrayList<>();
        this.citas = new ArrayList<>();
    }

    public void registrarPaciente(Paciente paciente) {
        pacientes.add(paciente);
        System.out.println("Paciente registrado: " + paciente.getNombre() + " " + paciente.getApellido());
    }

    public Paciente buscarPaciente(String id) {
        for (Paciente p : pacientes) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        return null;
    }

    public void contratarEmpleado(Empleado empleado) {
        empleados.add(empleado);
        System.out.println(empleado.obtenerTipo() + " contratado: " + empleado.getNombre() + " " + empleado.getApellido());
    }

    public List<Medico> getMedicosDisponibles() {
        List<Medico> medicos = new ArrayList<>();
        for (Empleado e : empleados) {
            if (e instanceof Medico && e.isActivo()) {
                medicos.add((Medico) e);
            }
        }
        return medicos;
    }

    public void agendarCita(Paciente paciente, Medico medico, LocalDateTime fechaHora, String motivo) {
        String idCita = "CITA-" + (citas.size() + 1);
        CitaMedica cita = new CitaMedica(idCita, paciente, medico, fechaHora, motivo);
        cita.calcularCosto();
        citas.add(cita);
        System.out.println("Cita agendada exitosamente: " + cita);
    }

    public void cambiarEstadoCita(String idCita, EstadoCita nuevoEstado) {
        for (CitaMedica cita : citas) {
            if (cita.getId().equals(idCita)) {
                cita.setEstado(nuevoEstado);
                System.out.println("Cita " + idCita + " cambiada a estado: " + nuevoEstado);
                return;
            }
        }
        System.out.println("Cita no encontrada.");
    }

    public void mostrarEmpleados() {
        System.out.println("\n--- EMPLEADOS ---");
        for (Empleado e : empleados) {
            System.out.println(e);
            System.out.println("  Salario calculado: $" + e.calcularSalario());
        }
    }

    public void mostrarPacientes() {
        System.out.println("\n--- PACIENTES ---");
        for (Paciente p : pacientes) {
            System.out.println(p);
        }
    }

    public void mostrarCitas() {
        System.out.println("\n--- CITAS ---");
        for (CitaMedica c : citas) {
            System.out.println(c);
        }
    }

    public String getNombre() { return nombre; }
    public String getDireccion() { return direccion; }
    public List<Empleado> getEmpleados() { return new ArrayList<>(empleados); }
    public List<Paciente> getPacientes() { return new ArrayList<>(pacientes); }
    public List<CitaMedica> getCitas() { return new ArrayList<>(citas); }

    public void demostrarPolimorfismo() {
        System.out.println("\n--- CALCULAR SALARIO ---");
        for (Empleado e : empleados) {
            System.out.println(e.obtenerTipo() + " " + e.getNombre() + ": $" + e.calcularSalario());
        }
    }
}