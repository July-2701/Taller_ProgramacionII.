/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.hospital;

public class Especialidad {

    private String codigo;
    private String nombre;
    private String descripcion;
    private double costoConsulta;

    public Especialidad(String codigo, String nombre, String descripcion, double costoConsulta) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.costoConsulta = (costoConsulta > 0) ? costoConsulta : 0;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public double getCostoConsulta() { return costoConsulta; }

    public void setCostoConsulta(double costoConsulta) {
        if (costoConsulta > 0) {
            this.costoConsulta = costoConsulta;
        }
    }

    @Override
    public String toString() {
        return nombre + " (Costo: $" + costoConsulta + ")";
    }
}
