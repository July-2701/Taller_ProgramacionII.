/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.abstractas;

import java.time.LocalDate;
import java.time.Period;


public abstract class Empleado extends Persona {
    private String legajo;
    private LocalDate fechaContratacion;
    protected double salarioBase;
    private boolean activo;
    
    public Empleado(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                    String email, String legajo, LocalDate fechaContratacion, double salarioBase) {
        
        super(id, nombre, apellido, fechaNacimiento, email);
        
        this.legajo = legajo;
        this.fechaContratacion = fechaContratacion;
        this.salarioBase = (salarioBase > 0) ? salarioBase : 0;
        this.activo = true;
    }
    public abstract double calcularSalario();
    
    public int antiguedad() {
        return Period.between(fechaContratacion, LocalDate.now()).getYears();
    }
    
    public String getLegajo() {
        return legajo;
    }
    
    public LocalDate getFechaContratacion() {
        return fechaContratacion;
    }
    
    public double getSalarioBase() {
        return salarioBase;
    }
    
    public boolean isActivo() {
        return activo;
    }
    
    public void setSalarioBase(double salarioBase) {
        if (salarioBase > 0) {
            this.salarioBase = salarioBase;
        }
    }
    
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    @Override
    public String obtenerTipo() {
        return "Empleado";
    }
}
