/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.principal;

import modelo.enums.Turno;
import modelo.hospital.Hospital;
import modelo.personas.Cirujano;
import modelo.personas.Enfermero;
import modelo.personas.Medico;
import modelo.personas.Paciente;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class SistemaHospitalDemo {

    public static void main(String[] args) {
        
        Hospital hospital = new Hospital("Hospital Yusepe", "Carrera 13 #45-12, Cartagena");

        System.out.println("--- SISTEMA DE GESTION HOSPITALARIA _ HOSPITAL YUSEPE ---\n");

        // Pacientes con los nombres que pediste
        Paciente lian = new Paciente("P001", "Lian", "Rodriguez", LocalDate.of(2000, 5, 12), 
                                    "lian@email.com", "HC-2026001", "O+");

        Paciente camila = new Paciente("P002", "Camila", "Ocampo", LocalDate.of(2007, 8, 25), 
                                      "camila@email.com", "HC-2026002", "A+");

        Paciente julian = new Paciente("P003", "Julian", "Rojas", LocalDate.of(2000, 1, 10), 
                                      "julian@email.com", "HC-2026003", "B-");

        Paciente yojan = new Paciente("P004", "Yojan", "Torres", LocalDate.of(2006, 10, 26), 
                                     "yojan@email.com", "HC-2026004", "AB+");

        Paciente samuel = new Paciente("P005", "Samuel", "Rodelo", LocalDate.of(2007, 12, 9), 
                                      "samuel@email.com", "HC-2026005", "O-");

        lian.agregarAlergia("Penicilina");
        camila.agregarAlergia("Polen");
        julian.agregarAlergia("Mariscos");

        hospital.registrarPaciente(lian);
        hospital.registrarPaciente(camila);
        hospital.registrarPaciente(julian);
        hospital.registrarPaciente(yojan);
        hospital.registrarPaciente(samuel);

        Medico medico1 = new Medico("M001", "Dr. Andres", "Gonzales", LocalDate.of(1985, 4, 20), 
                                   "andres@email.com", "LEG-001", LocalDate.of(2016, 1, 10), 
                                   3800000, "MED-12345", "Cardiología", Turno.MANANA);

        Cirujano cirujano1 = new Cirujano("C001", "Dra. Valentina", "Lavandida", LocalDate.of(1988, 7, 15), 
                                         "valentina@email.com", "LEG-002", LocalDate.of(2019, 5, 5), 
                                         4500000, "CIR-67890", "Cirugía General", Turno.TARDE);

        Enfermero enfermero1 = new Enfermero("E001", "Juan", "Pereria", LocalDate.of(1993, 2, 28), 
                                            "juan@email.com", "LEG-003", LocalDate.of(2021, 8, 20), 
                                            1950000, Turno.NOCHE, "Urgencias");

        hospital.contratarEmpleado(medico1);
        hospital.contratarEmpleado(cirujano1);
        hospital.contratarEmpleado(enfermero1);

        hospital.demostrarPolimorfismo();

        System.out.println("\n--- AGENDANDO CITAS ---");
        hospital.agendarCita(lian, medico1, LocalDateTime.of(2026, 4, 15, 8, 30), "Dolor de pecho");
        hospital.agendarCita(camila, cirujano1, LocalDateTime.of(2026, 4, 16, 10, 0), "Control post-operatorio");

        System.out.println("\n--- INFORMACION DEL HOSPITAL YUSEPE ---");
        hospital.mostrarPacientes();
        hospital.mostrarEmpleados();
        hospital.mostrarCitas();
        
        System.out.println("Proyecto Del Hospital De Yusepe Listo");

    }
}