/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemagestionhospitalaria;

/**
 *
 * @author magal
 */
public class SistemaGestionHospitalaria {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
